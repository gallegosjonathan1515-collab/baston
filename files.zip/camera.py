"""Captura de video en un hilo propio: siempre entrega el frame más reciente."""
import threading
import time

import cv2


class CameraStream:
    def __init__(self, index: int, width: int, height: int):
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # evita acumular frames viejos
        if not self.cap.isOpened():
            raise RuntimeError(f"No se pudo abrir la cámara {index}")

        self._frame = None
        self._frame_id = 0
        self._lock = threading.Lock()
        self._running = False
        self._thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self._running = True
        self._thread.start()
        return self

    def _loop(self):
        while self._running:
            ok, frame = self.cap.read()
            if not ok:
                time.sleep(0.01)
                continue
            with self._lock:
                self._frame = frame
                self._frame_id += 1

    def read(self):
        """Devuelve (id_del_frame, frame). El id permite saltarse frames ya procesados."""
        with self._lock:
            return self._frame_id, self._frame

    def stop(self):
        self._running = False
        self._thread.join(timeout=1)
        self.cap.release()
