"""Wrapper de YOLOv8 Nano: devuelve detecciones simples ya filtradas."""
from dataclasses import dataclass

from ultralytics import YOLO

import config


@dataclass
class Detection:
    cls_id: int
    name: str
    conf: float
    x1: int
    y1: int
    x2: int
    y2: int

    @property
    def area(self) -> int:
        return max(self.x2 - self.x1, 0) * max(self.y2 - self.y1, 0)


class Detector:
    def __init__(self):
        self.model = YOLO(config.MODEL_PATH)
        self.names = self.model.names

    def detect(self, frame) -> list[Detection]:
        results = self.model.predict(
            frame,
            imgsz=config.IMGSZ,
            conf=config.CONF,
            classes=config.ALLOWED_CLASSES,
            verbose=False,
        )[0]

        detections = []
        for box in results.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            cls_id = int(box.cls[0])
            detections.append(
                Detection(cls_id, self.names[cls_id], float(box.conf[0]), x1, y1, x2, y2)
            )
        return detections
