"""División espacial en 3 zonas y nivel de urgencia por zona."""
import config


def zone_bounds(frame_w: int) -> dict:
    a = int(frame_w * config.ZONE_SPLIT[0])
    b = int(frame_w * config.ZONE_SPLIT[1])
    return {"L": (0, a), "C": (a, b), "R": (b, frame_w)}


def urgency(det, frame_area: int) -> int:
    """1 = lejos, 2 = medio, 3 = cerca (según el tamaño del bounding box)."""
    ratio = det.area / frame_area
    if ratio >= config.NEAR_RATIO:
        return 3
    if ratio >= config.MID_RATIO:
        return 2
    return 1


def analyze(detections, frame_w: int, frame_h: int) -> dict:
    """Devuelve {'L': nivel, 'C': nivel, 'R': nivel} con el nivel 0-3 de cada zona.

    Un objeto grande puede ocupar varias zonas a la vez.
    """
    levels = {"L": 0, "C": 0, "R": 0}
    bounds = zone_bounds(frame_w)
    frame_area = frame_w * frame_h

    for d in detections:
        u = urgency(d, frame_area)
        box_w = max(d.x2 - d.x1, 1)
        for zone, (zx1, zx2) in bounds.items():
            overlap = min(d.x2, zx2) - max(d.x1, zx1)
            if overlap > 0 and overlap / box_w >= config.MIN_OVERLAP:
                levels[zone] = max(levels[zone], u)
    return levels
