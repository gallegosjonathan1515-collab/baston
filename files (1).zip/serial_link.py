"""Enlace serial en hilo propio: nunca bloquea la captura/inferencia.

- send() solo guarda el comando más reciente (no hay cola que crezca).
- El hilo lo transmite cuando cambia y, además, cada HEARTBEAT_S (para el watchdog del Arduino).
- Si el puerto se cae, reintenta abrirlo solo.
"""
import threading
import time

import serial

import config

SAFE_LINE = "L:0,R:0,C:0\n"


class SerialLink:
    def __init__(self, port: str, baud: int = config.SERIAL_BAUD,
                 heartbeat: float = config.HEARTBEAT_S, retry_s: float = 2.0):
        self.port, self.baud = port, baud
        self.heartbeat, self.retry_s = heartbeat, retry_s
        self._latest = None
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._running = False
        self._connected = False
        self._thread = threading.Thread(target=self._loop, daemon=True)

    @property
    def connected(self) -> bool:
        return self._connected

    def start(self):
        self._running = True
        self._thread.start()
        return self

    def send(self, line: str):
        with self._lock:
            changed = line != self._latest
            self._latest = line
        if changed:
            self._wake.set()

    def _open(self):
        ser = serial.Serial(self.port, self.baud, timeout=0, write_timeout=0.5)
        time.sleep(2.0)  # muchos Arduino se reinician al abrir el puerto
        return ser

    def _loop(self):
        ser = None
        while self._running:
            if ser is None:
                try:
                    ser = self._open()
                    self._connected = True
                    print(f"[serial] conectado a {self.port}")
                except (serial.SerialException, OSError):
                    self._connected = False
                    time.sleep(self.retry_s)
                    continue

            self._wake.wait(timeout=self.heartbeat)  # despierta por cambio o por heartbeat
            self._wake.clear()
            with self._lock:
                line = self._latest
            if line is None:
                continue
            try:
                ser.write(line.encode("ascii"))
            except (serial.SerialException, OSError):
                print("[serial] conexión perdida, reintentando...")
                self._connected = False
                try:
                    ser.close()
                except Exception:
                    pass
                ser = None

        if ser is not None:  # al salir: motores apagados
            try:
                ser.write(SAFE_LINE.encode("ascii"))
                ser.close()
            except Exception:
                pass

    def stop(self):
        self._running = False
        self._wake.set()
        self._thread.join(timeout=2)
